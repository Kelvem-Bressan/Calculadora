document.addEventListener('DOMContentLoaded', inicio);

let primeiraCarta = '';
let segundaCarta = '';
let travado = false;
let cartas = [];
let cartasViradas = 0;

function inicio() {
    cartas = [
        "audi.jpg", "audi.jpg", "bentley.png", "bentley.png", 
        "bugatti.jpg", "bugatti.jpg", "bmw.png", "bmw.png", 
        "chevrolet.png", "chevrolet.png", "ferrari.jpg", "ferrari.jpg", 
        "fiat.jpg", "fiat.jpg", "ford.png", "ford.png", 
        "honda.png", "honda.png", "hondam.png", "hondam.png", 
        "hyundai.png", "hyundai.png", "iveco.png", "iveco.png", 
        "jaguar.png", "jaguar.png", "lambo.png", "lambo.png", 
        "man.png", "man.png", "mercedes.jpg", "mercedes.jpg", 
        "mik.jpg", "mik.jpg", "nissan.jpg", "nissan.jpg", 
        "alfa.jpg", "alfa.jpg", "reno.png", "reno.png", 
        "scania.png", "scania.png", "toyota.png", "toyota.png", 
        "volks.png", "volks.png", "volvo.png", "volvo.png", 
        "yamaha.png", "yamaha.png"
    ];

    embaralhar();
    mostrar();
}

function embaralhar() {
    for (let i = cartas.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        let emb = cartas[i];
        cartas[i] = cartas[j];
        cartas[j] = emb;
    }
}

function mostrar() {
    const tabela = document.getElementById("tabela");
    tabela.innerHTML = '';

    const cartasPorLinha = 10;
    const linhas = Math.ceil(cartas.length / cartasPorLinha);

    let tabelaHTML = '';  

    for (let i = 0; i < linhas; i++) {
        let linhaHTML = '<tr>';

        for (let j = 0; j < cartasPorLinha; j++) {
            const indice = i * cartasPorLinha + j;
            if (indice >= cartas.length) break;

            const img = `<img src="img/fundo.jpg" cartas="${cartas[indice]}" viradas="false" onclick="virarCarta(this)">`;
            linhaHTML += `<td>${img}</td>`;
        }

        linhaHTML += '</tr>';
        tabelaHTML += linhaHTML;
    }

    tabela.innerHTML = tabelaHTML;  
}

function virarCarta(carta) {
    if (travado || carta.getAttribute('viradas') === "true") {
        return;
    }

    carta.src = 'img/' + carta.getAttribute('cartas');
    carta.setAttribute('viradas', "true");
    cartasViradas++;

    if (!primeiraCarta) {
        primeiraCarta = carta;
    } else {
        segundaCarta = carta;
        verificarPar();
    }
}

function verificarPar() {
    travado = true;

    if (primeiraCarta.getAttribute('cartas') === segundaCarta.getAttribute('cartas')) {
        resetar();
    } else {
        setTimeout(function() {
            primeiraCarta.src = "img/fundo.jpg";
            segundaCarta.src = "img/fundo.jpg";
            primeiraCarta.setAttribute('viradas', "false");
            segundaCarta.setAttribute('viradas', "false");
            resetar();
        }, 1000);
    }
}

function resetar() {
    primeiraCarta = '';
    segundaCarta = '';
    travado = false;
}
