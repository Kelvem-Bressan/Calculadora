document.addEventListener('DOMContentLoaded', () => {

    let numeroAtual = ''; 
    let numeroAnterior = ''; 
    let operador = ''; 
    let resultado = false; 
    
    const tela = document.getElementById('tela'); 

 
    const botoesNumeros = document.querySelectorAll('.numero'); 
    botoesNumeros.forEach(button => {
        button.addEventListener('click', (event) => {
            if (resultado) {
                numeroAtual = event.target.value; 
                resultado = false;
            } else {
                numeroAtual += event.target.value; 
            }
            tela.textContent = numeroAtual; 
        });
    });

    const botoesOperacoes = document.querySelectorAll('.operacao');
    botoesOperacoes.forEach(button => {
        button.addEventListener('click', (event) => {
            if (numeroAtual === '') return; 

            if (numeroAnterior !== '') {
                calcular(); 
            }
            operador = event.target.value; 
            numeroAnterior = numeroAtual; 
            numeroAtual = '';
            tela.textContent = numeroAnterior + operador ; 
        });
    })

    document.querySelector('input[value="="]').addEventListener('click', () => {
        if (numeroAnterior !== '' && numeroAtual !== '') {
            calcular(); 
            resultado = true; 
        }
    });
    
    function calcular() {
        let res;
        const numA = parseFloat(numeroAnterior); 
        const numB = parseFloat(numeroAtual); 

        switch (operador) {
            case '+':
                res = numA + numB;
                break;
            case '-':
                res = numA - numB;
                break;
            case '*':
                res = numA * numB;
                break;
            case '/':
                res = numA / numB;
                break;
            default:
                return;
        }

        numeroAtual = res.toString(); 
        
        alert("Valor: " + numeroAtual);
        tela.textContent = resultado;
        numeroAnterior = ''; 
        operador = ''; 
        numeroAtual = '';
        tela.textContent = '';
    }

    document.querySelector('input[name="C"]').addEventListener('click', () => {
        numeroAtual = '';
        numeroAnterior = '';
        operador = '';
        tela.textContent = ''; 
    });
});
